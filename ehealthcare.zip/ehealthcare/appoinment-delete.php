<?php

include 'db.php';

$serial_no = $_GET['serial_no'];

$sql = " DELETE FROM `appoinment` WHERE serial_no = $serial_no ";

mysqli_query($con, $sql);

header('location:appoinment-display.php');

?>