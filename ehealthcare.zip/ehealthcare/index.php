<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>E-Health Care</title>
	<link rel="stylesheet" href="style.css">
</head>
<body>
	<div class="wrapper">
			<nav class="navbar">
				<ul>
					<li><a class="active" href="#">Home</a></li>
					<li><a href="doctorlist.php">Doctorlist</a></li>
					<li><a href="donorslist.php">Donorslist</a></li>
					<li><a href="appoinment.php">Appoinment</a></li>
					<li><a href="blog.html">Blog</a></li>
					<li><a href="contact.php">Contact</a></li>
					<li><a href="login.php">Logout</a></li>
				</ul>
			</nav>
			<div class="center">
			<h1>Welcome To E-Health Care</h1>
			
		</div>
</body>
</html>