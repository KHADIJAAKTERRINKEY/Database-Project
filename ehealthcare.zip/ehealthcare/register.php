<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Register</title>
    <link rel="stylesheet" href="register-style.css">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,700&display=swap" rel="stylesheet">
</head>
<body>
    <main>
        <div class="background">
            <div class="text">
                <h1>Register</h1>
                <p>Have Account? <a href="login.php">Login</a></p>
            </div>
            <div class="box">
                <form class="form" action="" method="post">
                    <input type="text" class="fullname" name="fullname" placeholder="Full Name" required>
                    <input type="email" class="email" name="email" placeholder="someone@abc.com" required>
                    <input type="text" class="username" name="username" placeholder="Username" required>
                    <input type="password" class="password" name="password" placeholder="Password" required>
                    <input type="submit" class="button" name="register" value="Register">
                </form>
            </div>
        </div>
    </main>
</body>
</html>
<?php 

$conn= mysqli_connect('localhost', 'root', '', 'ehc');

if(isset($_POST['register'])){
    
    $fullname=$_POST['fullname'];
    $email=$_POST['email'];
    $username=$_POST['username'];
    $password=$_POST['password'];

    
    $sql= "INSERT INTO register(fullname,email,username,password)
    VALUES ( '{$fullname}', '{$email}','{$username}', '{$password}')";
    
    $create_user_query= mysqli_query($conn,$sql);
    
    if(!$create_user_query){
            die("Query Failed". mysqli_error($conn));
        }
    else{
        header("Location: ./login.php"); 
//        echo "<h1>Registration Completed</h1>";
    }
    
}


?>