-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 15, 2021 at 11:44 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.4.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ehc`
--

-- --------------------------------------------------------

--
-- Table structure for table `appoinment`
--

CREATE TABLE `appoinment` (
  `serial_no` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phone_number` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appoinment`
--

INSERT INTO `appoinment` (`serial_no`, `name`, `phone_number`) VALUES
(1, 'Raisa Islam', '01861695353'),
(2, 'Sabiha Samad', '01703587337'),
(3, 'Rinkey', '01628692352'),
(4, 'Lucky', '01869299407'),
(5, 'Farhan', '01521533689'),
(6, 'Piku', '01850266932'),
(7, 'Rakib', '01878525361'),
(8, 'Riya', '01822334456'),
(9, 'Sathi', '01712345678'),
(10, 'Mawa', '01918765432'),
(11, 'Samiha', '01612345676'),
(12, 'Aziz', '01319876541'),
(13, 'rimi', '0179431934548');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(200) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `subject`, `message`) VALUES
(1, 'rinkey', 'khadijaakterrinkey@gmail.com', 'dentist', 'avsbvjv'),
(2, 'Raisa Islam', 'raisa@gmail.com', 'doctor', 'segjgl');

-- --------------------------------------------------------

--
-- Table structure for table `doctorlist`
--

CREATE TABLE `doctorlist` (
  `doctor_no` int(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone_number` varchar(50) NOT NULL,
  `bio` varchar(250) NOT NULL,
  `join_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctorlist`
--

INSERT INTO `doctorlist` (`doctor_no`, `name`, `phone_number`, `bio`, `join_date`) VALUES
(1, 'Dr. P. K. Das', '01879981431', 'Throat Specialist & Surgeon', '2021-06-28'),
(2, 'Prof. Dr. Muhammad Yousuf', '09612247247', 'Gastroenterology', '2019-12-02'),
(3, 'Dr. Md. Habibur Rahman', '0186789356', 'Neurology Specialist', '2021-01-05'),
(4, 'dr. sakibul hasan', '', '', '0000-00-00'),
(5, 'dr. ABC', '0193687o76', 'Dematologists', '2020-03-05'),
(6, 'Dr. ', '01712244556', 'Ophthalmologists', '2018-04-05'),
(7, 'dr. minar', '01911224455', 'Cardiologists', '2020-05-05'),
(8, 'dr. Nurul chy', '01922445575', 'Endocrinologists', '2010-12-12'),
(9, 'Dr. Parvez', '01628692352', 'Nephrologists', '2011-11-11');

-- --------------------------------------------------------

--
-- Table structure for table `donorslist`
--

CREATE TABLE `donorslist` (
  `donor_no` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phone_number` varchar(50) NOT NULL,
  `last_donor` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `donorslist`
--

INSERT INTO `donorslist` (`donor_no`, `name`, `phone_number`, `last_donor`) VALUES
(1, 'rinkey', '01879981431', '2020-12-31'),
(2, 'sabiha', '01703587227', '2021-02-05'),
(3, 'sabia', '0009457488', '2019-06-22'),
(4, 'Rakib', '00448664759', '2021-01-26'),
(5, 'hafsa', '01613356776', '2021-01-01'),
(6, 'Dew', '01412345678', '2020-01-20'),
(7, 'tasnim', '01319876532', '2020-02-02'),
(8, 'Lucky', '01869299407', '2020-06-26'),
(9, 'Sathi', '01319876532', '2019-03-13'),
(10, 'Sieam', '01922457834', '2018-08-18'),
(11, 'Ahnaf chy', '01879984231', '2020-08-26'),
(12, 'Robin', '01724659139', '2021-05-15');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `fullname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`fullname`, `email`, `username`, `password`) VALUES
('khadija akter', 'khadijaakterrinkey@gmail.com', 'rinkey', '5678'),
('madiha chy', 'madihachy@gmail.com', 'tasnim', '9090'),
('Micky chy', 'mickychy@gmail.com', 'micky', '0000'),
('madiha chy', 'madihachy@gmail.com', 'tasnim', '1234'),
('Ayesha Chy', 'ayeshachy@gmail.com', 'ayesha', '2222'),
('Abc', 'abc@gmail.com', 'Abc', '1234'),
('Nargis Akter Lucky', 'nargisakterlucky@gmail.com', 'Lucky', '3434');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appoinment`
--
ALTER TABLE `appoinment`
  ADD PRIMARY KEY (`serial_no`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctorlist`
--
ALTER TABLE `doctorlist`
  ADD PRIMARY KEY (`doctor_no`);

--
-- Indexes for table `donorslist`
--
ALTER TABLE `donorslist`
  ADD PRIMARY KEY (`donor_no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appoinment`
--
ALTER TABLE `appoinment`
  MODIFY `serial_no` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `doctorlist`
--
ALTER TABLE `doctorlist`
  MODIFY `doctor_no` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `donorslist`
--
ALTER TABLE `donorslist`
  MODIFY `donor_no` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;