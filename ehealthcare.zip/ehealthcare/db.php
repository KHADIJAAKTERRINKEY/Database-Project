<?php
 $con = mysqli_connect("localhost","root","","ehc") or die(mysql_error());
?>