<?php

include 'db.php';

$doctor_no = $_GET['doctor_no'];

$sql = " DELETE FROM `doctorlist` WHERE doctor_no = $doctor_no ";

mysqli_query($con, $sql);

header('location:display.php');

?>