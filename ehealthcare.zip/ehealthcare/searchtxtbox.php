<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title> Search Data and Update it </title>
	<style>
		body{
			background-color: whitesmoke;
		}
		input{
			width: 40%;
			height: 5%;
			border: 1px;
			border-radius: 05px;
			padding: 8px 15px 8px 15px;
			margin: 10px 0px 15px 0px;
			box-shadow: 1px 1px 2px 1px grey;
		}
	</style>
</head>
<body>
	<center>
		<h1> Search Data into Textbox and Update </h1>
		<form action="" method="POST" style="background-color: lightblue">
		    <input type="text" name="doctor_no" placeholder="Enter doctor no for Search"/><br/>
			<input type="submit" name="Search" value="Search Data"/>	
		</form>

		<?php
		$conn = mysqli_connect("localhost","root","");
		$db = mysqli_select_db($conn,'ehc');

		if(isset($_POST['Search'])){
			$doctor_no = $_POST['doctor_no'];

			$query = "SELECT * FROM doctorlist where doctor_no='$doctor_no' ";
			$query_run = mysqli_query($conn,$query);

			while($row = mysqli_fetch_array($query_run))
			{
				?>
				<form action="" method="POST">
					<input type="hidden" name="doctor_no" value="<?php echo $row['doctor_no'] ?>"/><br>
					<input type="text" name="name" value="<?php echo $row['name'] ?>"/><br>
				    <input type="text" name="phone_number" value="<?php echo $row['phone_number'] ?>"/><br>
				    <input type="text" name="bio" value="<?php echo $row['bio'] ?>"/><br>
					<input type="text" name="join_date" value="<?php echo $row['join_date'] ?>"/><br>
					<input type="submit" name="submit" value="submit">

				</form>
				<?php
			}
		}

		?>
	</center>
</body>
</html>

<?php
	$conn = mysqli_connect("localhost","root","");
	$db = mysqli_select_db($conn,'ehc');

	if(isset($_POST['submit']))
	{
		$name = $_POST['name'];
		$phone_number = $_POST['phone_number'];
		$bio = $_POST['bio'];
		$join_date = $_POST['join_date'];

		$query = "UPDATE 'doctorlist' set name='$_POST[name]',phone_number='$_POST[phone_number]',bio='$_POST[bio]',join_date='$_POST[join_date]' where doctor_no='$_POST[doctor_no]' ";
		$query_run = mysqli_query($conn,$query);
		if($query_run)
		{
			echo '<script> aleart("Data Updated") </script>';
		}
		else
		{
			echo '<script> aleart("Data Not Updated") </script>';
		}
	}
?>