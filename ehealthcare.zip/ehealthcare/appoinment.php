<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Appoinment</title>
    <link rel="stylesheet" href="appoinment.css">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,700&display=swap" rel="stylesheet">
</head>
<body>
    <main>
        <div class="background">
            <div class="text">
                <form class="form" action="" method="post">
                    <input type="text" name="patient_no" placeholder="Serial No" required>
                    <input type="text" name="name" placeholder="Name" required>
                    <input type="tel"  name="phone_number" placeholder="Phone number" required>
                    <input type="submit" name="submit" value="Submit">
                    <button><a href="appoinment-display.php"> Display </a></button>
                </form>
            </div>
        </div>
    </main>
</body>
</html>
<?php 

$conn= mysqli_connect('localhost', 'root', '', 'ehc');

if(isset($_POST['submit'])){

    $doctor_no=$_POST['serial_no'];
    $name=$_POST['name'];
    $phone_number=$_POST['phone_number'];

    
    $sql= "INSERT INTO appoinment(serial_no,name,phone_number)
    VALUES ( '{$serial_no}','{$name}', '{$phone_number}')";
    
    $create_user_query= mysqli_query($conn,$sql);
    
    if(!$create_user_query){
            die("Query Failed". mysqli_error($conn));
        }
    else{
        header("Location: ./appoinment.php"); 
    }
    
}


?>