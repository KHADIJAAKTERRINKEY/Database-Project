<?php session_start(); ?>
<?php 

$conn= mysqli_connect('localhost', 'root', '', 'ehc');

if(isset($_POST['submit'])){
    
    $name=$_POST['username'];
    $pass=$_POST['password'];
    
    $sql="SELECT * FROM register WHERE username ='{$name}'";
    $select_user_query = mysqli_query($conn, $sql);

    if(!$select_user_query){
        
        die("Query Failed". mysqli_error($conn));
        
    }
    while($row=mysqli_fetch_assoc($select_user_query)){
        
        $fullname=$_POST['fullname'];
        $email=$_POST['email'];
        $username=$_POST['username'];
        $password=$_POST['password'];
        
    }
    
    if($name !== $username && $pass !==  $password){
        
        header("Location: login.php");  
        
    }
    
    if($name == $username && $pass ==  $password){
        
        $_SESSION['username'] = $username;
        $_SESSION['firstname'] = $firstname;
        $_SESSION['lastname'] = $lastname;
        $_SESSION['position'] = $position;
        $_SESSION['password'] = $password;
        $_SESSION['status'] = $status;

        header("Location: index.php"); 
        
    }
    
    
        
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
    <link rel="stylesheet" href="login-style.css">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,700&display=swap" rel="stylesheet">
</head>
<body>
    <main>
        <div class="background">
            <div class="text">
                <h1>Login</h1>
                <p>No Account? <a href="register.php">Register</a></p>
            </div>
            <div class="box">
                <form action="" class="form" method="post">
                    <input type="text" class="username" name="username" placeholder="Username" required>
                    <input type="password" class="password" name="password" placeholder="Password" required>
                    <input type="submit" class="button" name="submit" value="Login">
                </form>
            </div>
        </div>
    </main>
</body>
</html>