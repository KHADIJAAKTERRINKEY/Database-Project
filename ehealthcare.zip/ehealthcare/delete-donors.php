<?php

include 'db.php';

$donor_no = $_GET['donor_no'];

$sql = " DELETE FROM `donorslist` WHERE donor_no = $donor_no ";

mysqli_query($con, $sql);

header('location:donors-display.php');

?>