<?php  
/*include('db.php');

// Feedback USER
if (isset($_POST['submit'])) {
  // receive all input values from the form
  $name = mysqli_real_escape_string($con, $_POST['name']);
  $email = mysqli_real_escape_string($con, $_POST['email']);
  $subject = mysqli_real_escape_string($con, $_POST['subject']);
  $message = mysqli_real_escape_string($con, $_POST['message']);

  // form validation: ensure that the form is correctly filled
  if (empty($name)) { array_push($errors, "Name is required"); }
  if (empty($email)) { array_push($errors, "Email is required"); }
  if (empty($subject)) { array_push($errors, "Subject is required"); }
  if (empty($message)) { array_push($errors, "Message is required"); }

  // register user if there are no errors in the form
  if (count($errors) == 0) {
    $query = "INSERT INTO contact (name, email, subject, message) 
          VALUES('$name', '$email', '$subject', '$message')";
    $query1 = mysqli_query($con, $query);
    $row = mysqli_fetch_array($query1,MYSQLI_ASSOC);
    $active = $query1['active'];

    $count = mysqli_num_rows($query1);

    header("location:index.php");

}
}*/
?>
<?php 

$conn= mysqli_connect('localhost', 'root', '', 'ehc');

if(isset($_POST['submit'])){
    
    $id=$_POST['id'];
    $name=$_POST['name'];
    $email=$_POST['email'];
    $subject=$_POST['subject'];
    $message=$_POST['message'];

    
    $sql= "INSERT INTO contact(id,name,email,subject,message)
    VALUES ('{$id}', '{$name}', '{$email}','{$subject}', '{$message}')";
    
    $create_user_query= mysqli_query($conn,$sql);
    
    if(!$create_user_query){
            die("Query Failed". mysqli_error($conn));
        }
    else{
        header("Location: index.php"); 
    }
    
}


?>
<!DOCTYPE html>
<html>
<head>
	<title>Contact us</title>
	<link rel="stylesheet" type="text/css" href="contact-style.css">
	<link href="https://fonts.googleapis.com/css?family=Quicksand&display=swap" rel="stylesheet">
	<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
</head>
<body>

	<div class="container">
		<div class="contact-box">
			<div class="left"></div>
			<div class="right">
        <form  action="" method="post">
				<h2>Contact Us</h2>
        <input type="text" class="field" placeholder="id" name='id'>
				<input type="text" class="field" placeholder="name" name='name'>
				<input type="text" class="field" placeholder="email" name='email'>
				<input type="text" class="field" placeholder="subject" name='subject'>
				<textarea placeholder="message" class="field" name='message'></textarea>
				<button class="btn" name='submit'>Submit</button>
        </form>
			</div>
		</div>
	</div>
</body>
</html>