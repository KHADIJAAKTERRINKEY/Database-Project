<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doctor</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="doctorlist-style.css">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,700&display=swap" rel="stylesheet">
</head>
<body>
    <main>
        <div class="background">
            <div class="text">
                <form class="form" action="" method="post">
                    <input type="text" name="doctor_no" placeholder="Doctor No" required>
                    <input type="text" name="name" placeholder="Name" required>
                    <input type="tel"  name="phone_number" placeholder="Phone number" required>
                    <input type="text"  name="bio" placeholder="Bio" required>
					<input type="date"  name="join_date" placeholder="Join Date" required>
                    <input type="submit" name="submit" value="Submit">
                    <button><a href="display.php">Display</a></button>
                </form>
            </div>
        </div>
    </main>
</body>
</html>
<?php 

$conn= mysqli_connect('localhost', 'root', '', 'ehc');

if(isset($_POST['submit'])){

    $doctor_no=$_POST['doctor_no'];
    $name=$_POST['name'];
    $phone_number=$_POST['phone_number'];
    $bio=$_POST['bio'];
    $join_date=$_POST['join_date'];

    
    $sql= "INSERT INTO doctorlist (doctor_no,name,phone_number,bio,join_date)
    VALUES ( '{$doctor_no}','{$name}', '{$phone_number}','{$bio}', '{$join_date}')";
    
    $create_user_query= mysqli_query($conn,$sql);
    
    if(!$create_user_query){
            die("Query Failed". mysqli_error($conn));
        }
    else{
        header("Location: ./doctorlist.php"); 
    }
    
}


?>