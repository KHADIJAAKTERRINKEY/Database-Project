<?php
 
 include 'db.php';
 
 $donor_no = $_GET['donor_no'];
 $sql_query = "SELECT * FROM donorslist WHERE donor_no=$donor_no";
 $result = mysqli_query($con, $sql_query);
 $row = mysqli_fetch_row($result);
 
 if(isset($_POST['done'])){
 
 $name = $_POST['name'];
 $phone_number = $_POST['phone_number'];
 $last_donor = $_POST['last_donor'];
 $sql = " update donorslist set name='$name', phone_number='$phone_number', last_donor='$last_donor' where donor_no=$donor_no "; 
 $query = mysqli_query($con,$sql);
 
 header('location:donorslist.php');
 }
 
?>

<!DOCTYPE html>
<html>
<head>
 <title></title>
 
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://m...content-available-to-author-only...n.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://a...content-available-to-author-only...s.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://c...content-available-to-author-only...e.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://m...content-available-to-author-only...n.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  <style>
		body{
			
          background-image: url("images/blood-donate.jpg");
          background-size: cover;
	        height: 100vh;
		}
		input{
			width: 40%;
			border: 1px;
			border-radius: 05px;
			padding: 8px 15px 8px 15px;
			margin: 10px 0px 15px 0px;
			box-shadow: 1px 1px 2px 1px grey;
		}
	</style>
</head>
<body>
 
 <div class="col-lg-6 m-auto">
 
 <form method="post">
 
 <br><br><div class="card">
 
 <div class="card-header bg-dark">
 <h1 class="text-white text-center">  Edit </h1>
 </div><br>
 
 <label> Name </label><br>
 <input type="text" name="name" value="<?=$row[1]?>" class="form-control"> <br><br>
 
 <label> Phone Number </label><br>
 <input type="text" name="phone_number" value="<?=$row[2] ?>" class="form-control"> <br><br>
 
 <label> Last Donor </label><br>
 <input type="text" name="last_donor" value="<?=$row[3] ?>" class="form-control"> <br><br>
 
 <button class="btn btn-success" type="submit" name="done"> Submit </button><br>
 
 </div>
 </form>
 </div>
</body>
</html>